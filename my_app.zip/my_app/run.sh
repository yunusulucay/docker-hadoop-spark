docker network rm hadoopNetwork
docker network create --driver=bridge --subnet=172.25.0.0/16 hadoopNetwork

docker build -t my-hadoop-base:1.0 .

docker run -itd --network="hadoopNetwork" --ip=172.25.0.100 -p 50070:50070 -p 8088:8088 --name master --hostname master my-hadoop-base:1.0
docker run -itd --network="hadoopNetwork" --ip=172.25.0.101 --name slave1 --hostname slave1 my-hadoop-base:1.0
docker run -itd --network="hadoopNetwork" --ip=172.25.0.102 --name slave2 --hostname slave2 my-hadoop-base:1.0
docker run -itd --network="hadoopNetwork" --ip=172.25.0.103 --name slave3 --hostname slave3 my-hadoop-base:1.0

docker exec -it master bash -c 'service ssh start'
docker exec -it slave1 bash -c 'service ssh start'
docker exec -it slave2 bash -c 'service ssh start'
docker exec -it slave3 bash -c 'service ssh start'

docker exec -i master sh -c 'cat > /etc/hosts' < config/hosts
docker exec -i slave1 sh -c 'cat > /etc/hosts' < config/hosts
docker exec -i slave2 sh -c 'cat > /etc/hosts' < config/hosts
docker exec -i slave3 sh -c 'cat > /etc/hosts' < config/hosts

docker cp master:/root/.ssh/authorized_keys .
docker exec -i slave1 sh -c 'cat > /root/.ssh/authorized_keys' < authorized_keys
docker exec -i slave2 sh -c 'cat > /root/.ssh/authorized_keys' < authorized_keys
docker exec -i slave3 sh -c 'cat > /root/.ssh/authorized_keys' < authorized_keys

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hadoop-env.sh' < config/hadoop-env.sh
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hadoop-env.sh' < config/hadoop-env.sh
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hadoop-env.sh' < config/hadoop-env.sh
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hadoop-env.sh' < config/hadoop-env.sh

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/core-site.xml' < config/core-site.xml
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/core-site.xml' < config/core-site.xml
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/core-site.xml' < config/core-site.xml
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/core-site.xml' < config/core-site.xml

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hdfs-site.xml' < config/hdfs-site.xml
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hdfs-site.xml' < config/hdfs-site.xml
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hdfs-site.xml' < config/hdfs-site.xml
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/hdfs-site.xml' < config/hdfs-site.xml

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/yarn-site.xml' < config/yarn-site.xml
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/yarn-site.xml' < config/yarn-site.xml
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/yarn-site.xml' < config/yarn-site.xml
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/yarn-site.xml' < config/yarn-site.xml

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/mapred-site.xml' < config/mapred-site.xml
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/mapred-site.xml' < config/mapred-site.xml
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/mapred-site.xml' < config/mapred-site.xml
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/mapred-site.xml' < config/mapred-site.xml

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/masters' < config/masters
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/masters' < config/masters
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/masters' < config/masters
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/masters' < config/masters

docker exec -i master sh -c 'cat > /hadoop-3.3.2/etc/hadoop/workers' < config/workers
docker exec -i slave1 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/workers' < config/workers
docker exec -i slave2 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/workers' < config/workers
docker exec -i slave3 sh -c 'cat > /hadoop-3.3.2/etc/hadoop/workers' < config/workers

docker exec -it master bash -c 'echo "Y" | /hadoop-3.3.2/bin/hdfs namenode -format'
#docker exec -it master bash -c '/hadoop-3.3.2/sbin/start-dfs.sh'
#docker exec -it master bash -c '/hadoop-3.3.2/sbin/start-yarn.sh'

docker exec -it master bash -c 'wget https://dlcdn.apache.org/spark/spark-3.2.1/spark-3.2.1-bin-hadoop3.2.tgz'
docker exec -it master bash -c 'tar -xvf spark-3.2.1-bin-hadoop3.2.tgz'
docker exec -i master sh -c 'cat > /spark-3.2.1-bin-hadoop3.2/conf/spark-defaults.conf' < config/spark-defaults.conf

docker exec -it master bash