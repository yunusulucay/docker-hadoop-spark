from pyspark.sql import SparkSession

spark = SparkSession.builder.appName("test").getOrCreate()

sample_data = ((440, True, 134), (477,True,126), (426,False,175), (284,False,218),
               (159,False,224), (112,False,220))

columns = ["value","is_anomaly","prediction"]

df = spark.createDataFrame(data=sample_data, schema=columns)

df.write.csv("file:///saved_csv.csv")
